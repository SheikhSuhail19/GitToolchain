import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ApiRepositoryService {

  constructor(private http: HttpClient) { }

  getData(url: string) {
    const headers = new HttpHeaders({
      // 'Authorization': 'Bearer 5bRLmTmWtPEP89K-Nhdu',
      // 'Authorization': 'Bearer GbCR5-_7U11RDzDQZpan',
      'Authorization': 'Bearer qU52dcURtbzoT2kzeT4i',
    });

    const options = {
      headers: headers,
    };

    return this.http.get(url, options);


  }
}




// getData(){
//   //  let url= "https://jsonplaceholder.typicode.com/users/";
//   //  let url= "https://jsonplaceholder.typicode.com/posts";
//   let url= "http://localhost:8080/api/team2/v1/projects/all/details";
//   return this.http.get(url);
// }