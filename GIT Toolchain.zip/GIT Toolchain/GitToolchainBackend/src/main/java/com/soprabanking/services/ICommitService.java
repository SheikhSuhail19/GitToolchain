package com.soprabanking.services;

import com.soprabanking.dto.CommitDto;

import java.util.List;

public interface ICommitService {
    List<CommitDto> getCommits(String projectId, String branchName, String privateToken);
}
