package com.soprabanking.services;

public interface IRepositoryService {
}
