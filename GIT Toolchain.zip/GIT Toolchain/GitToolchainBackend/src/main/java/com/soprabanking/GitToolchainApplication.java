package com.soprabanking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GitToolchainApplication {

    public static void main(String[] args) {

        SpringApplication.run(GitToolchainApplication.class, args);

    }

}
