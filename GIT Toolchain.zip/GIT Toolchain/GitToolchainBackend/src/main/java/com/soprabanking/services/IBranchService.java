package com.soprabanking.services;

import com.soprabanking.dto.BranchDto;

import java.util.Map;

public interface IBranchService {
    public Map<String, Object> getAllBranches(String id, String access_token, Boolean pagination, int page);
}
