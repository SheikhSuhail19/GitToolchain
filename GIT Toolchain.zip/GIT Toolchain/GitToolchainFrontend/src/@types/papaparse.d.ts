declare module 'papaparse' {
    const anyVariable: any; // Or provide more specific typings here
    export = anyVariable;
  }