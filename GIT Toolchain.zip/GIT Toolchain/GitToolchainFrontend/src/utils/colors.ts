export const DEFAULT_LABEL_COLOR = '#696363';
export const GREY = 'grey';
