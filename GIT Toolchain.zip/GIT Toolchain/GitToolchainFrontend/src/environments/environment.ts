export const environment = {
    gitlabToken: 'your token',
    production: false,
};
