export interface User{  
    id: number;
    username: string;
    name: string;
    state: string;
    avatar_url: string;
    web_url: string;
}